describe('Sample Cypress Test', () => {
  it('Visits the Example page', () => {
    cy.visit('/');
    cy.contains('Kitchen Sink');
  });
});